/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jschmele <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/02 12:21:42 by jschmele          #+#    #+#             */
/*   Updated: 2018/09/02 12:42:21 by jschmele         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

int		inspection(int **numbers, int row, int col, int value)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < 9)
	{
		if (numbers[i][col] == value)
			return (0);
		i++;
	}
	i = 0;
	while (i < 9)
	{
		if (numbers[row][i] == value)
			return (0);
		i++;
	}
	return (1);
}

int		check_rubick(int **numbers, int row, int col, int value)
{
	int x;
	int y;

	y = 0;
	while (y < 3)
	{
		x = 0;
		while (x < 3)
		{
			if (numbers[row - (row % 3) + x][col - (col % 3) + y] == value)
				return (0);
			x++;
		}
		y++;
	}
	return (1);
}

int		sudoku_sol(int **numbers, int x, int y)
{
	int i;

	i = 1;
	if (y == 9)
	{
		y = 0;
		x++;
	}
	if (x == 9)
		return (1);
	if (numbers[x][y] != 0)
		return (sudoku_sol(numbers, x, y + 1));
	while (i < 10)
	{
		if (inspection(numbers, COORDI) && check_rubick(numbers, COORDI))
		{
			numbers[x][y] = i;
			if (sudoku_sol(numbers, x, y + 1))
				return (1);
			else
				numbers[x][y] = 0;
		}
		i += 1;
	}
	return (0);
}
